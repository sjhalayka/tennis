using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test_script : MonoBehaviour
{
    protected Rigidbody rb3d;
    Vector3 last_velocity;
    Vector3 last_mouse_click_pos;
    GameObject sphere;// = GameObject.CreatePrimitive(PrimitiveType.Sphere);
    
    void OnEnable()
    {
        rb3d = GetComponent<Rigidbody>();
        sphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
    }
    
    void OnCollisionEnter(Collision col)
    {
        if(col.gameObject.name == "Plane")
        {
            // https://docs.unity3d.com/ScriptReference/Collision-contacts.html
            Vector3 N = col.contacts[0].normal;
            rb3d.velocity = -(2.0f * Vector3.Dot(last_velocity, N) * N - last_velocity);
        }
    }
    
    // Start is called before the first frame update
    void Start()
    {
        rb3d.velocity = new Vector3(-1, 0, 0);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown (0))
        {
            Plane p = new Plane (Camera.main.transform.forward , transform.position);
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
            RaycastHit hit;
            
            if (Physics.Raycast(ray, out hit, 100))
            {
                if(hit.collider.gameObject.name == "Plane")
                {
                    last_mouse_click_pos = hit.point;
                    sphere.transform.position = last_mouse_click_pos;
                }
            }
        }
    }
    
    void FixedUpdate()
    {
        Vector3 grav = new Vector3(0f, -9.81f, 0f);
        
        last_velocity = rb3d.velocity;
        
        rb3d.velocity += grav * Time.deltaTime;
        rb3d.position += rb3d.velocity * Time.deltaTime;
    }
}
